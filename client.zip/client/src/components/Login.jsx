import React, { useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

export default function Login() {
  const { login } = useContext(AuthContext);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    const res = await fetch(`${process.env.REACT_APP_API_URL || 'http://localhost:5000'}/api/auth/login`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (data.token) {
      login(data.user, data.token);
    } else {
      alert(data.msg || 'Login failed');
    }
  };

  return (
    <form onSubmit={submit}>
      <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="username" required />
      <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="password" required />
      <button type="submit">Login</button>
    </form>
  );
}
