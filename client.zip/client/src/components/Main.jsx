import React, { useContext, useEffect } from 'react';
import Login from './Login';
import Chat from './Chat';
import { AuthContext } from '../context/AuthContext';
import { createSocket } from '../socket/socket';

export default function Main(){
  const { user, token } = useContext(AuthContext);

  useEffect(() => {
    if (token) {
      const s = createSocket(token);
      // request notification permission
      if (Notification && Notification.permission !== 'granted') {
        Notification.requestPermission();
      }
      return () => s && s.disconnect();
    }
  }, [token]);

  return user ? <Chat /> : <Login />;
}
