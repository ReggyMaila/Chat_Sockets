import React, { useContext, useState, useEffect } from 'react';
import { AuthContext } from '../context/AuthContext';
import { getSocket } from '../socket/socket';

export default function Chat(){
  const { user, logout } = useContext(AuthContext);
  const [room, setRoom] = useState({ _id: 'general', name: 'General' });
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const socket = getSocket();

  useEffect(() => {
    if (!socket) return;
    socket.emit('joinRoom', { roomId: room._id });
    socket.on('room:history', (history) => setMessages(history));
    socket.on('message:new', (msg) => setMessages(prev => [...prev, msg]));
    return () => {
      socket.emit('leaveRoom', { roomId: room._id });
      socket.off('room:history');
      socket.off('message:new');
    };
  }, [room, socket]);

  const send = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    socket.emit('message', { roomId: room._id, text });
    setText('');
  };

  return (
    <div>
      <header>
        <h2>Welcome, {user.displayName || user.username}</h2>
        <button onClick={logout}>Logout</button>
      </header>
      <main style={{ display: 'flex' }}>
        <section style={{ flex: 1 }}>
          <h3>{room.name}</h3>
          <div style={{ height: 300, overflowY: 'auto' }}>
            {messages.map(m => (<div key={m._id}><strong>{m.from?.displayName || m.from?.username}</strong>: {m.text}</div>))}
          </div>
          <form onSubmit={send}>
            <input value={text} onChange={e=>setText(e.target.value)} placeholder="Message..." />
            <button type="submit">Send</button>
          </form>
        </section>
      </main>
    </div>
  );
}
