# Socket.io Chat (Deploy Setup)

This starter repository contains a React client and Node.js + Socket.io server configured for deployment.
It includes example `.env` files with placeholders for production URLs (Render / Netlify).

## Deploy setup (placeholders included)

- Client `.env` -> `REACT_APP_API_URL=https://your-backend.onrender.com`
- Server `.env` -> `FRONTEND_URL=https://your-frontend.netlify.app`

## Running locally (development)

1. Install & run the server:
```bash
cd server
npm install
# create .env from .env.example and set MONGO_URI and JWT_SECRET
npm run dev
```

2. Install & run the client:
```bash
cd client
npm install
# set REACT_APP_API_URL in client/.env (for local use: http://localhost:5000)
npm start
```

## Deploy notes

- Deploy server to Render/Heroku/Railway and set environment variables (MONGO_URI, JWT_SECRET, FRONTEND_URL).
- Deploy client to Netlify/Vercel and set `REACT_APP_API_URL` to your backend URL.
- Use a managed MongoDB Atlas cluster for production.

