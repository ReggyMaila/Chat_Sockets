const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Room = require('../models/Room');
const Message = require('../models/Message');

const jwtSecret = process.env.JWT_SECRET || 'dev_secret';

module.exports = (io) => {
  const onlineUsers = new Map(); // socketId -> userId

  io.use(async (socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next();
    try {
      const payload = jwt.verify(token, jwtSecret);
      socket.user = payload;
      next();
    } catch (e) { next(); }
  });

  io.on('connection', (socket) => {
    const user = socket.user;
    if (user) {
      onlineUsers.set(socket.id, user.id);
      // mark online
      User.findByIdAndUpdate(user.id, { online: true }).exec();
      io.emit('presence:update', { userId: user.id, online: true });
    }

    socket.on('joinRoom', async ({ roomId }) => {
      socket.join(roomId);
      // send last messages
      const messages = await Message.find({ room: roomId }).sort({ createdAt: 1 }).limit(200).populate('from', 'username displayName');
      socket.emit('room:history', messages);
    });

    socket.on('leaveRoom', ({ roomId }) => {
      socket.leave(roomId);
    });

    socket.on('message', async ({ roomId, text, toUserId }) => {
      if (!user) return;
      const msg = new Message({
        room: roomId,
        from: user.id,
        to: toUserId || null,
        text,
      });
      await msg.save();
      const populated = await msg.populate('from', 'username displayName').execPopulate?.() || msg;
      io.to(roomId).emit('message:new', populated);
    });

    socket.on('typing', ({ roomId, isTyping }) => {
      if (!user) return;
      socket.to(roomId).emit('typing', { userId: user.id, username: user.username, isTyping });
    });

    socket.on('message:read', async ({ messageId }) => {
      if (!user) return;
      const msg = await Message.findById(messageId);
      if (!msg) return;
      if (!msg.readBy.includes(user.id)) {
        msg.readBy.push(user.id);
        await msg.save();
        io.to(msg.room.toString()).emit('message:read', { messageId, userId: user.id });
      }
    });

    socket.on('disconnect', () => {
      const uid = onlineUsers.get(socket.id);
      onlineUsers.delete(socket.id);
      if (uid) {
        User.findByIdAndUpdate(uid, { online: false, lastSeen: new Date() }).exec();
        io.emit('presence:update', { userId: uid, online: false, lastSeen: new Date() });
      }
    });
  });
};
