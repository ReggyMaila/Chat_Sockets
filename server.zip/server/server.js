require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const { connect } = require('./config/db');
const authRoutes = require('./routes/auth');

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());

app.use('/api/auth', authRoutes);

const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server, {
  cors: { origin: process.env.FRONTEND_URL || '*', methods: ['GET','POST'] }
});

const socketHandler = require('./socket');
socketHandler(io);

const PORT = process.env.PORT || 5000;
connect(process.env.MONGO_URI).then(() => {
  server.listen(PORT, () => console.log('Server listening on', PORT));
}).catch(err => {
  console.error('Failed to connect to DB', err);
  server.listen(PORT, () => console.log('Server listening without DB on', PORT));
});
