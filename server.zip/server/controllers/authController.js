const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const jwtSecret = process.env.JWT_SECRET || 'dev_secret';

exports.register = async (req, res) => {
  const { username, password, displayName } = req.body;
  try {
    const exists = await User.findOne({ username });
    if (exists) return res.status(400).json({ msg: 'Username taken' });
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    const u = new User({ username, passwordHash: hash, displayName });
    await u.save();
    res.json({ msg: 'Registered' });
  } catch (err) { res.status(500).json({ err: err.message }); }
};

exports.login = async (req, res) => {
  const { username, password } = req.body;
  try {
    const u = await User.findOne({ username });
    if (!u) return res.status(400).json({ msg: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, u.passwordHash);
    if (!ok) return res.status(400).json({ msg: 'Invalid credentials' });
    const token = jwt.sign({ id: u._id, username: u.username }, jwtSecret, { expiresIn: '7d' });
    res.json({ token, user: { id: u._id, username: u.username, displayName: u.displayName }});
  } catch (err) { res.status(500).json({ err: err.message }); }
};
